/*
 * libspm - Field solvers
 *
 * Full Multigrid (FMG) and Conjugate Gradient (CG) solvers for
 * Helmholtz-like PDEs arising in diffeomorphic registration.
 * Includes both 3-component (optim3d) and N-component (optimN) variants.
 *
 * Original code: John Ashburner
 * Copyright (C) 2011-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_FIELD_H
#define LIBSPM_FIELD_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* --- 3-component Full Multigrid solver (for 3D vector fields) --- */
void spm_fmg3(spm_size n0[], float *a0, float *b0, double param[],
              int c, int nit, float *u0, float *scratch);
void spm_cgs3(spm_size dm[], float A[], float b[], double param[],
              double tol, int nit, float x[], float r[], float p[], float Ap[]);
spm_size spm_fmg3_scratchsize(spm_size n0[], int use_hessian);

/* --- N-component Full Multigrid solver (for scalar/vector fields) --- */
void spm_fmg(spm_size n0[], float *a0, float *b0, double param[],
             double scal[], int c, int nit, float *u0, float *scratch);
spm_size spm_fmg_scratchsize(spm_size n0[]);

/* --- Direct solvers and operators --- */
void spm_solve(spm_size dm[], float a[], float b[], double s[],
               double scal[], float u[]);
void spm_LtLf(spm_size dm[], float f[], double s[], double scal[], float g[]);
void spm_LtWLf(spm_size dm[], float f[], float h[], double s[],
               double scal[], float g[]);
double spm_diaginv(spm_size dm[], float a[], float b[], double s[],
                   double scal[], float u[]);

/* --- Multigrid restriction/prolongation --- */
void spm_resize_vol(spm_size na[], float *a, spm_size nc[], float *c, float *b);
void spm_restrict_vol(spm_size na[], float *a, spm_size nc[], float *c, float *b);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_FIELD_H */

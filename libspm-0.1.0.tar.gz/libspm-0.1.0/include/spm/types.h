/*
 * libspm - Standalone C library from SPM numerical routines
 * Type definitions for standalone (non-MEX) compilation
 *
 * Original code: Copyright (C) 1991-2023 Wellcome Centre for Human Neuroimaging
 * This file: GPL-2.0-only
 */

#ifndef LIBSPM_TYPES_H
#define LIBSPM_TYPES_H

#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

/* These match the fallback definitions in spm_mex.h */
typedef signed   long long int  spm_signed_index;
typedef unsigned long long int  spm_index;
typedef unsigned long long int  spm_size;

#endif /* LIBSPM_TYPES_H */

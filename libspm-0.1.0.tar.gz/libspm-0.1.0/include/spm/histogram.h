/*
 * libspm - Joint histogram computation
 *
 * 2D joint histogram of two uint8 volumes with affine mapping,
 * used for mutual information registration.
 *
 * Original code: John Ashburner
 * Copyright (C) 1999-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_HISTOGRAM_H
#define LIBSPM_HISTOGRAM_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/*
 * Compute 2D joint histogram of two uint8 volumes.
 *
 * M    - 4x4 affine mapping (column-major, 16 doubles)
 * g    - reference volume (uint8)
 * f    - source volume (uint8)
 * dg   - dimensions of g [3]
 * df   - dimensions of f [3]
 * H    - output 256x256 histogram (65536 doubles)
 * s    - smoothing FWHM [3]
 */
void spm_hist2(double M[16], unsigned char g[], unsigned char f[],
               const spm_size dg[3], const spm_size df[3],
               double H[65536], float s[3]);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_HISTOGRAM_H */

/*
 * libspm - B-spline interpolation
 *
 * B-spline coefficient computation and sampling for 1D/3D data.
 * Supports degrees 0-7 with mirror and wrap boundary conditions.
 * Based on Thevenaz & Unser algorithms.
 *
 * Original code: John Ashburner
 * Copyright (C) 2001-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_BSPLINES_H
#define LIBSPM_BSPLINES_H

#ifdef __cplusplus
extern "C" {
#endif

/*
 * When compiled with -DIMAGE_SINGLE (default for libspm), the data type
 * is float; otherwise double.
 */
#ifdef IMAGE_SINGLE
#define SPM_IMAGE_DTYPE float
#else
#define SPM_IMAGE_DTYPE double
#endif

/* Compute B-spline poles for a given degree */
int spm_bspline_poles(int degree, int *np, double p[]);

/* 1D B-spline coefficient computation with wrap boundary */
void spm_bsplinc_wrap(SPM_IMAGE_DTYPE c[], int m, double p[], int np);

/* 1D B-spline coefficient computation with mirror boundary */
void spm_bsplinc_mirror(SPM_IMAGE_DTYPE c[], int m, double p[], int np);

/* Sample a 3D volume of B-spline coefficients at arbitrary coordinates */
SPM_IMAGE_DTYPE spm_bspline_sample3(
    SPM_IMAGE_DTYPE c[], int m0, int m1, int m2,
    SPM_IMAGE_DTYPE x0, SPM_IMAGE_DTYPE x1, SPM_IMAGE_DTYPE x2,
    int d[], int (*bnd[])());

/* Sample with gradient computation */
SPM_IMAGE_DTYPE spm_bspline_dsample3(
    SPM_IMAGE_DTYPE c[], int m0, int m1, int m2,
    SPM_IMAGE_DTYPE x0, SPM_IMAGE_DTYPE x1, SPM_IMAGE_DTYPE x2,
    int d[], SPM_IMAGE_DTYPE *pg0, SPM_IMAGE_DTYPE *pg1, SPM_IMAGE_DTYPE *pg2,
    int (*bnd[])());

/* Boundary condition function pointers */
int spm_bspline_mirror(void);
int spm_bspline_wrap(void);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_BSPLINES_H */

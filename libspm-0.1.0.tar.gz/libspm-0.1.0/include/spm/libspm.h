/*
 * libspm - Standalone C library from SPM numerical routines
 *
 * This library packages the ~10% of SPM that is written in C:
 * numerical solvers, image resampling, histogram routines, and
 * diffeomorphic registration engines. These are separable from
 * the MATLAB code and compiled as a native shared library.
 *
 * Modules:
 *   diffeo       - Diffeomorphic registration (Geodesic Shooting / DARTEL)
 *   field        - Full Multigrid and Conjugate Gradient PDE solvers
 *   regularisers - Membrane, bending, and elasticity regularization
 *   bsplines     - B-spline interpolation (degrees 0-7)
 *   histogram    - Joint histogram for mutual-information registration
 *   gmm          - Gaussian Mixture Models for tissue segmentation
 *   expm         - Matrix exponential (2x2, 3x3)
 *   boundary     - Boundary condition control (circulant/Neumann/Dirichlet)
 *   openmp       - Thread management
 *
 * Original C code: Copyright (C) 1991-2023 Wellcome Centre for Human Neuroimaging
 * Authors: John Ashburner, Yael Balbastre, Mikael Brudfors, et al.
 * License: GPL-2.0-only
 */

#ifndef LIBSPM_H
#define LIBSPM_H

#define LIBSPM_VERSION_MAJOR 0
#define LIBSPM_VERSION_MINOR 1
#define LIBSPM_VERSION_PATCH 0

#include "spm/types.h"
#include "spm/boundary.h"
#include "spm/diffeo.h"
#include "spm/field.h"
#include "spm/regularisers.h"
#include "spm/bsplines.h"
#include "spm/histogram.h"
#include "spm/gmm.h"
#include "spm/expm.h"
#include "spm/openmp.h"

#endif /* LIBSPM_H */

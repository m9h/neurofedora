/*
 * libspm - Gaussian Mixture Model library
 *
 * GMM for tissue segmentation with missing data handling,
 * sufficient statistics, and Wishart priors.
 *
 * Original code: John Ashburner, Mikael Brudfors & Yael Balbastre
 * Copyright (C) 2020-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_GMM_H
#define LIBSPM_GMM_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Cholesky decomposition */
void spm_gmm_choldc(spm_size n, double a[], double p[]);

/* Cholesky solve */
void spm_gmm_cholls(spm_size n, const double a[], const double p[],
                    const double b[], double x[]);

/* Digamma function */
double spm_gmm_psi(double z);

/* Compute workspace sizes needed */
void spm_gmm_space_needed(spm_size M, spm_size K,
                          spm_size *m0, spm_size *m1, spm_size *m2);

/* E-step: sufficient statistics with missing data */
double spm_gmm_suffstats_missing(
    spm_size nf[], float mf[], float vf[], unsigned char label[],
    spm_size K, double mu[], double b[], double W[], double nu[],
    double gam[], double lnP[],
    spm_size nm[], spm_size skip[], spm_size lkp[], float lp[],
    double s0_ptr[], double s1_ptr[], double s2_ptr[], double H[]);

/* Compute responsibilities */
double spm_gmm_responsibilities(
    spm_size nf[], spm_size skip[], float mf[], float vf[],
    unsigned char label[],
    spm_size K, double mu[], double b[], double W[], double nu[],
    double gam[], double lnP[],
    spm_size K1, spm_size lkp[], float lp[], float r[]);

/* INU gradients */
double spm_gmm_INUgrads(
    spm_size nf[], float mf[], float vf[], unsigned char label[],
    spm_size K, double mu[], double b[], double W[], double nu[],
    double gam[], double lnP[],
    spm_size nm[], spm_size skip[], spm_size lkp[], float lp[],
    spm_size ic, float g1[], float g2[]);

/* Fill missing data */
int spm_gmm_fill_missing(
    spm_size nf[], float mf[], float vf[], unsigned char label[],
    spm_size K, double mu[], double b[], double W[], double nu[],
    double gam[], double lnP[],
    spm_size nm[], spm_size skip[], spm_size lkp[], float lp[],
    float mf1[]);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_GMM_H */

/*
 * libspm - Boundary condition handling
 *
 * Circulant (periodic) and Neumann (reflecting) boundary conditions
 * for field operations and PDE solvers.
 *
 * Original code: John Ashburner
 * Copyright (C) 2011-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_BOUNDARY_H
#define LIBSPM_BOUNDARY_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SPM_BOUND_CIRCULANT  0
#define SPM_BOUND_NEUMANN    1
#define SPM_BOUND_DIRICHLET  2
#define SPM_BOUND_SLIDING    3

void spm_set_boundary(int type);
int  spm_get_boundary(void);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_BOUNDARY_H */

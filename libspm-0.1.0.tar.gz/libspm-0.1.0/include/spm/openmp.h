/*
 * libspm - OpenMP thread management
 *
 * Get/set number of threads. Respects SPM_NUM_THREADS environment variable.
 *
 * Original code: Yael Balbastre
 * Copyright (C) 2019-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_OPENMP_H
#define LIBSPM_OPENMP_H

#ifdef __cplusplus
extern "C" {
#endif

void spm_set_num_threads(int t);
int  spm_get_num_threads(void);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_OPENMP_H */

/*
 * libspm - Regularization operators
 *
 * Membrane energy, bending energy, and linear elasticity regularization
 * for deformation fields. Finite-difference stencils and multigrid operators.
 *
 * Original code: John Ashburner
 * Copyright (C) 2011-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_REGULARISERS_H
#define LIBSPM_REGULARISERS_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Velocity to momentum (L'L * v) */
void spm_vel2mom(spm_size dm[], float f[], double s[], float g[]);

/* Gauss-Seidel relaxation */
void spm_relax(spm_size dm[], float a[], float b[], double s[],
               int nit, float u[]);

/* A*p operator (regulariser + Hessian) */
void spm_Atimesp(spm_size dm[], float A[], double param[],
                 float p[], float Ap[]);

/* Sum of squared residuals */
double spm_sumsq(spm_size dm[], float a[], float b[], double s[], float u[]);

/* Approximation to the trace of the inverse */
double spm_trapprox(spm_size dm[], float a[], double s[]);

/* Generate regularisation kernel in frequency domain */
void spm_kernel(spm_size dm[], double s[], float f[]);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_REGULARISERS_H */

/*
 * libspm - Matrix exponential
 *
 * Matrix exponential of 2x2 and 3x3 matrices, and Lie group exponential
 * (scaling and squaring) for velocity fields.
 *
 * Original code: John Ashburner
 * Copyright (C) 2011-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_EXPM_H
#define LIBSPM_EXPM_H

#ifdef __cplusplus
extern "C" {
#endif

/* 3x3 matrix exponential via Pade(2,2) approximant (lower accuracy, faster) */
void spm_expm22(float a[9], float l[9]);

/* 3x3 matrix exponential via Pade(3,3) approximant (higher accuracy) */
void spm_expm33(float a[9], float l[9]);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_EXPM_H */

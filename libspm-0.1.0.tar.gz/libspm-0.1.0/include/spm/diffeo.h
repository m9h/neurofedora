/*
 * libspm - Diffeomorphic registration (Geodesic Shooting / DARTEL)
 *
 * 3D diffeomorphism operations: composition of deformations, Jacobians,
 * determinants, push/pull image warping, velocity-to-momentum,
 * inverse deformation fields, and more.
 *
 * Original code: John Ashburner
 * Copyright (C) 2007-2022 Wellcome Centre for Human Neuroimaging
 * GPL-2.0-only
 */

#ifndef LIBSPM_DIFFEO_H
#define LIBSPM_DIFFEO_H

#include "spm/types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* --- Deformation composition --- */
void spm_composition(spm_size dm[], spm_size mm,
                     float *A, float *B, float *C);
void spm_composition_jacobian(spm_size dm[], spm_size mm,
                              float *A, float *JA, float *B, float *JB,
                              float *C, float *JC);
void spm_composition_jacdet(spm_size dm[], spm_size mm,
                            float *A, float *JA, float *B, float *JB,
                            float *C, float *JC);

/* --- Small deformations --- */
void spm_smalldef(spm_size dm[], float sc, float v[], float t[]);
void spm_smalldef_jac(spm_size dm[], float sc, float v[], float t[], float J[]);

/* --- Push/pull (image warping through deformation fields) --- */
void spm_push(spm_size dm0[], spm_size m1, spm_size n,
              float Psi[], float F1[], float F0[], float S0[]);
void spm_pushc(spm_size dm0[], spm_size m1, spm_size n,
               float Psi[], float F1[], float F0[], float S0[]);
void spm_pull(spm_size dm0[], spm_size m1, spm_size n,
              float Psi[], float F0[], float F1[]);
void spm_pullc(spm_size dm0[], spm_size m1, spm_size n,
               float Psi[], float F0[], float F1[]);

/* --- Jacobian and determinant --- */
void spm_determinant(spm_size dm[], float J0[], float d[]);
void spm_def2det(spm_size dm[], float *Y, float *J, spm_signed_index s);
void spm_def2jac(spm_size dm[], float *Y, float *J, spm_signed_index s);

/* --- Divergence --- */
void spm_minmax_div(spm_size dm[], float v0[], double mnmx[]);
void spm_divergence(spm_size dm[], float v0[], float dv[]);

/* --- Gradients --- */
void spm_grad(spm_size dm[], spm_size N, float F[], float D[]);

/* --- Inverse deformation --- */
void spm_invdef(spm_size dim_y[3], float y[],
                spm_size dim_iy[3], float iy[],
                float M1[4][3], float M2[4][3]);

#ifdef __cplusplus
}
#endif

#endif /* LIBSPM_DIFFEO_H */

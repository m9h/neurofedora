/*
 * example_expm.c - Matrix exponential demo
 *
 * Computes the matrix exponential of a small rotation matrix
 * using the 3x3 expm routine from SPM's shoot engine.
 */

#include <stdio.h>
#include <string.h>

/* Use the internal headers directly (spm_mex.h provides standalone types) */
#include "spm_mex.h"
#include "shoot_expm3.h"
#include "shoot_boundary.h"
#include "spm_openmp.h"

int main(void)
{
    /* A = skew-symmetric matrix (infinitesimal rotation about z-axis) */
    float A[9] = {
         0.0f, -0.1f, 0.0f,
         0.1f,  0.0f, 0.0f,
         0.0f,  0.0f, 0.0f
    };
    float L[9];

    printf("libspm example: 3x3 matrix exponential\n\n");

    /* Compute expm(A) */
    memset(L, 0, sizeof(L));
    expm33(A, L);

    printf("Input A (skew-symmetric):\n");
    for (int i = 0; i < 3; i++)
        printf("  [%8.4f %8.4f %8.4f]\n", A[i*3+0], A[i*3+1], A[i*3+2]);

    printf("\nexpm(A) (rotation matrix):\n");
    for (int i = 0; i < 3; i++)
        printf("  [%8.4f %8.4f %8.4f]\n", L[i*3+0], L[i*3+1], L[i*3+2]);

    /* Demonstrate boundary condition API */
    set_bound(BOUND_NEUMANN);
    printf("\nBoundary condition set to: %d (Neumann)\n", get_bound());

    /* Demonstrate OpenMP thread control */
    printf("OpenMP threads: %d\n", spm_get_num_threads());

    return 0;
}

/*
 * test_basic.c - Smoke tests for libspm
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "spm_mex.h"
#include "shoot_expm3.h"
#include "shoot_boundary.h"
#include "spm_openmp.h"
#include "bsplines.h"
#include "hist2.h"

static int failures = 0;

#define ASSERT(cond, msg) do { \
    if (!(cond)) { \
        fprintf(stderr, "FAIL: %s (line %d)\n", msg, __LINE__); \
        failures++; \
    } else { \
        printf("  ok: %s\n", msg); \
    } \
} while(0)

static void test_expm33(void)
{
    printf("test_expm33\n");

    /* expm of zero matrix should be identity */
    float A[9] = {0};
    float L[9] = {0};

    expm33(A, L);

    /* Check diagonal ~1, off-diagonal ~0 */
    ASSERT(fabsf(L[0] - 1.0f) < 1e-5f, "expm(0)[0,0] == 1");
    ASSERT(fabsf(L[4] - 1.0f) < 1e-5f, "expm(0)[1,1] == 1");
    ASSERT(fabsf(L[8] - 1.0f) < 1e-5f, "expm(0)[2,2] == 1");
    ASSERT(fabsf(L[1]) < 1e-5f, "expm(0)[0,1] == 0");
    ASSERT(fabsf(L[3]) < 1e-5f, "expm(0)[1,0] == 0");
}

static void test_expm22(void)
{
    printf("test_expm22\n");

    /* expm22 = Pade(2,2) approximant on a 3x3 matrix (not 2x2!) */
    float A[9] = {0};
    float L[9] = {0};

    expm22(A, L);

    ASSERT(fabsf(L[0] - 1.0f) < 1e-5f, "expm22(0)[0,0] == 1");
    ASSERT(fabsf(L[4] - 1.0f) < 1e-5f, "expm22(0)[1,1] == 1");
    ASSERT(fabsf(L[8] - 1.0f) < 1e-5f, "expm22(0)[2,2] == 1");
    ASSERT(fabsf(L[1]) < 1e-5f, "expm22(0)[0,1] == 0");
}

static void test_boundary(void)
{
    printf("test_boundary\n");

    set_bound(BOUND_NEUMANN);
    ASSERT(get_bound() == BOUND_NEUMANN, "set/get Neumann");

    set_bound(BOUND_CIRCULANT);
    ASSERT(get_bound() == BOUND_CIRCULANT, "set/get circulant");

    set_bound(BOUND_DIRICHLET);
    ASSERT(get_bound() == BOUND_DIRICHLET, "set/get Dirichlet");
}

static void test_openmp(void)
{
    printf("test_openmp\n");

    int n = spm_get_num_threads();
    ASSERT(n >= 1, "at least 1 thread");

    spm_set_num_threads(2);
    /* May not change if OpenMP is not available, but shouldn't crash */
    ASSERT(spm_get_num_threads() >= 1, "set threads doesn't crash");
}

static void test_bspline_poles(void)
{
    printf("test_bspline_poles\n");

    int np = 0;
    double p[4] = {0};

    /* Degree 3 (cubic) should have 1 pole */
    int ok = get_poles(3, &np, p);
    ASSERT(ok == 0, "get_poles(3) succeeds");
    ASSERT(np == 1, "cubic B-spline has 1 pole");
    ASSERT(fabs(p[0] - (-2.0 + sqrt(3.0))) < 1e-10, "cubic pole value correct");
}

int main(void)
{
    printf("libspm basic tests\n\n");

    test_expm33();
    test_expm22();
    test_boundary();
    test_openmp();
    test_bspline_poles();

    printf("\n%s (%d failure(s))\n",
           failures ? "SOME TESTS FAILED" : "ALL TESTS PASSED", failures);

    return failures ? EXIT_FAILURE : EXIT_SUCCESS;
}
